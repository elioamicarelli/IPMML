library(foreign)
library(readstata13)
library(RANN)
nelda4 <- read.dta13("/home/ea/Documents/working_on/workshop/data/kennedyelat/nelda4b.dta")
# 
nelda4 <- subset(nelda4, multPart1 == 0, select = c(incosWin, year, incRun, incLimit, 
                                                    incSucc, electSuspend, incExtend, 
                                                    manipTime, concCan, 
                                                    oppPrev, oppBoycott, oppHarass,
                                                    mediaBias, econCrisis, recAid,
                                                    violPrior, intMonitor, westMonitor,
                                                    goodUS, westLink, polity2l1, 
                                                    goodGrow, pollExist, incApp, 
                                                    rgdpcgrl, dCPIl1, timeInc2,
                                                    realmarg_1, rgdppcGrow, tranGrowth))
nelda4$response<-as.factor(ifelse(nelda4$incosWin==1,"Yes","No"))
str(nelda4)
preProcValues <- preProcess(nelda4, method = c("knnImpute"))
newnelda4 <- predict(preProcValues, nelda4)
nelda4$polity2l1<-newnelda4$polity2l1
nelda4$rgdpcgrl<-newnelda4$rgdpcgrl
nelda4$dCPIl1<-newnelda4$dCPIl1
nelda4$timeInc2<-newnelda4$timeInc2
nelda4$realmarg_1<-newnelda4$realmarg_1
nelda4$rgdppcGrow<-newnelda4$rgdppcGrow
nelda4$tranGrowth<-newnelda4$tranGrowth
save(nelda4,file="/home/ea/Documents/working_on/workshop/data/electiondata.rda")

par(mfrow=c(1,2))
tree.elections<-tree(response ~.-incosWin, control = tree.control(nobs=nrow(train.nelda),minsize = 350),data= train.nelda)
plot(tree.elections)
tree.elections<-tree(response ~.-incosWin,split = "gini", control = tree.control(nobs=nrow(train.nelda),minsize = 1),data= train.nelda)
plot(tree.elections)

